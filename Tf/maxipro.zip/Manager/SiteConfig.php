<?php 
$SiteName="Maxifxpro";
$Color="#fff";
$Background="#00b556";
$Establishment_Year="2013";
$LiveChat='<script src="//code.tidio.co/kglwd6rlku3swvhmflpj5e8ziearmmyj.js" async></script>';
$MailerImage="https://www.incimages.com/uploaded_files/image/1920x1080/getty_818792802_402829.jpg";


//-----Email Configuration----->
$MailerName="Maxifxpro";
$SMTPhost='mail.maxifxpro.org';
$SiteEmail='support@maxifxpro.org';
$SitePassword='MaximumFX123est$';


?>